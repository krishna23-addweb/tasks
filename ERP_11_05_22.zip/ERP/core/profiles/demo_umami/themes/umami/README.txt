ABOUT UMAMI
-----------

Umami is the theme used for the "Umami food magazine" demonstration site.
The Umami theme uses Classy as its base theme.

ABOUT DRUPAL THEMING
--------------------

See https://www.drupal.org/docs/8/theming for more information on Drupal
theming.
